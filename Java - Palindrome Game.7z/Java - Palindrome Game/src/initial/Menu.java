//CS 143 project - Derrick Woods - 19 May 2019
package initial;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.swing.JOptionPane;

import initial.Game.STATE;

//The main, help and difficulty selection menus
public class Menu extends MouseAdapter{
	
	private Game game;
	private Board board;
	private Random r = new Random();
	private boolean saved = false; 
	
	public Menu(Game game, Board board) {
		this.game = game;
		this.board = board;
	}	
	 
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
				
		//Main menu
		if (Game.gameState == STATE.Menu) {
			//Play button
			if (board.mouseOver(mx, my, 870, 150, 200, 64)) {				
				Game.gameState = STATE.Select;
			}									
			//Help Button
			if (board.mouseOver(mx, my, 870, 250, 200, 64)) {
				Game.gameState = STATE.Help;
			}			
			//Quit Button
			if (board.mouseOver(mx, my, 870, 350, 200, 64)) {
				System.exit(1);
			}
		}		
		//Back button for help
		else if (Game.gameState == STATE.Help) {
			if (board.mouseOver(mx, my, 860, 350, 200, 64)) {
				Game.gameState = STATE.Menu;
				return;
			}
		}
		//Difficulty selection menu
		else if (Game.gameState == STATE.Select) {
			//Normal button
			if (board.mouseOver(mx, my, 860, 150, 200, 64)) {				
				Game.gameState = STATE.Game;
				game.addMouseListener(board);
				game.addMouseMotionListener(board);
				
				KeyInput.charPosition = 0;
				Game.difficulty = 0;
				Board.time = 0;
				for (int i = 0; i < board.playChars.length; i++) {
					board.playChars[i] = '\0';
				}
				for (int i = 0; i < board.choiceChars.length; i++) {
					board.choiceChars[i] = '\0';
				}
			}
			//Hard Button			
			if (board.mouseOver(mx, my, 860, 250, 200, 64)) {
				Game.gameState = STATE.Game;			
				game.addMouseListener(board);
				game.addMouseMotionListener(board);
				
				KeyInput.charPosition = 0;
				Game.difficulty = 1;
				Board.time = 0;
				Board.currentPalindrome = ""; 
				for (int i = 0; i < board.playChars.length; i++) {
					board.playChars[i] = '\0';
				}
				for (int i = 0; i < board.choiceChars.length; i++) {
					board.choiceChars[i] = '\0';
				}
			}
			//back button for select
			if (board.mouseOver(mx, my, 860, 350, 200, 64)) {
				Game.gameState = STATE.Menu;
				return;
			}
		}
	}
	
	public void mouseReleased (MouseEvent e){
		
	}			
	public void tick() {
		
	}
	
	//Change various aspects of g to be used in drawing the rectangles and words of the menus
	public void render(Graphics g) {
		//Main menu
		if (Game.gameState == STATE.Menu) {
			//Differing font sizes so the menu options fit
			Font fnt = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("Menu", 890, 70);
					
			g.setFont(fnt2);
			g.drawRect(860, 150, 200, 64);
			g.drawString("Play", 920, 190);
					
			g.setColor(Color.white);
			g.drawRect(860, 250, 200, 64);
			g.drawString("How to Play", 875, 290);
			
			g.setColor(Color.white);
			g.drawRect(860, 350, 200, 64);
			g.drawString("Quit", 920, 390);
		}
		//Help screen
		else if (Game.gameState == STATE.Help){
			Font fnt = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			Font fnt3 = new Font("arial", 1, 20);
			
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("How to Play", 810, 70);
					
			g.setFont(fnt3);
			g.drawString("Move letters from the lower area to the upper area to make palindromes", 640, 150);
			g.drawString("The order of the letters you arrange are all that matters, they may be organized in any way otherwise", 520, 190);
			g.drawString("Normal: Make any combination from the provided letters and learn if it is a palindrome", 590, 260);
			g.drawString("Hard: Only the exact palindrome that the letters come from will be accepted", 625, 300);
			
			g.setFont(fnt2);
			g.drawRect(860, 350, 200, 64);
			g.drawString("Back", 920, 390);
		}
		//Difficulty selection
		else if (Game.gameState == STATE.Select){
			Font fnt = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("SELECT DIFFICULTY", 700, 70);
					
			g.setFont(fnt2);
			g.drawRect(860, 150, 200, 64);
			g.drawString("Normal", 905, 190);
			
			g.drawRect(860, 250, 200, 64);
			g.drawString("Hard", 920, 290);
			
			g.setFont(fnt2);
			g.drawRect(860, 350, 200, 64);
			g.drawString("Back", 920, 390);
		}
	}
}
