//CS 143 project - Derrick Woods - 19 May 2019
package initial;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import initial.Game.STATE;

public class KeyInput extends KeyAdapter{
	
	private Game game;
	private Board board;
 
	public KeyInput(Game game, Board board) {	
		this.game = game;
		this.board = board;
	}
	
	public static int charPosition = 0;
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();	
		char keyChar = e.getKeyChar();
		
		//Control the psoition of any keyboard playChars entries
		if (Game.gameState == STATE.Game) {
			if (Character.isLetter(keyChar) || keyCode == KeyEvent.VK_BACK_SPACE || keyCode == KeyEvent.VK_SPACE
					|| keyCode == KeyEvent.VK_LEFT || keyCode == KeyEvent.VK_RIGHT || keyCode == KeyEvent.VK_DOWN || keyCode == KeyEvent.VK_UP)	{
				
				if (Character.isLetter(keyChar)) {
					keyChar = Character.toUpperCase(keyChar);
					
					for (int i = 0; i < board.choiceChars.length; i ++) {
						if (board.choiceChars[i] == keyChar) {
							if (board.playChars[charPosition] == '\0') {
								board.choiceChars[i] = '\0';
								board.playChars[charPosition] = keyChar;
								charPosition++;
								if (charPosition > 59) {
									charPosition = 59;
								}
								break;
							}
							else {
								board.choiceChars[i] = board.playChars[charPosition];
								board.playChars[charPosition] = keyChar;
								charPosition++;
								if (charPosition > 59) {
									charPosition = 59;
								}
								break;
							}
						}
					}
				}
				else if (keyCode == KeyEvent.VK_SPACE) {
					if (board.playChars[charPosition] != '\0') {
						for (int i = 0; i < board.choiceChars.length; i ++) {
							if (board.choiceChars[i] == '\0') {
								board.choiceChars[i] = board.playChars[charPosition];
								board.playChars[charPosition] = '\0';
								charPosition++;
								if (charPosition > 59) {
									charPosition = 59;
								}
								break;
							}
						}
					}
					else {
						charPosition++;
						if (charPosition > 59) {
							charPosition = 59;
						}
					}
				}
				else if (keyCode == KeyEvent.VK_BACK_SPACE) {
					if (board.playChars[charPosition] != '\0') {
						for (int i = 0; i < board.choiceChars.length; i ++) {
							if (board.choiceChars[i] == '\0') {
								board.choiceChars[i] = board.playChars[charPosition];
								board.playChars[charPosition] = '\0';
								charPosition--;
								if (charPosition < 0) {
									charPosition = 0;
								}
								break;
							}
						}
					}
					else {
						charPosition--;
						if (charPosition < 0) {
							charPosition = 0;
						}
					}
				}
				else if (keyCode == KeyEvent.VK_LEFT) {
					charPosition--;
					if (charPosition < 0) {
						charPosition = 0;
					}
				}
				else if (keyCode == KeyEvent.VK_RIGHT) {
					charPosition++;
					if (charPosition > 59) {
						charPosition = 59;
					}
				}
				else if (keyCode == KeyEvent.VK_UP) {
					charPosition -= 20;
					if (charPosition < 0) {
						charPosition = 0;
					}			
				}
				else if (keyCode == KeyEvent.VK_DOWN) {
					charPosition += 20;
					if (charPosition > 59) {
						charPosition = 59;
					}
				}
			}
		}
		
		//Pause screen on shift
		if (keyCode == KeyEvent.VK_SHIFT) {
			if (Game.gameState == STATE.Game)
				Game.gameState = STATE.Paused;
			else if (Game.gameState == STATE.Paused)
				Game.gameState = STATE.Game;
		}
		//Exit game on esc
		if (keyCode == KeyEvent.VK_ESCAPE) {
			System.exit(1);
		}
	}
}
