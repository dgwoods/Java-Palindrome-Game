//CS 143 project - Derrick Woods - 19 May 2019
package initial;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import initial.Game.STATE;

//Pause screen
public class PauseScreen extends MouseAdapter{
	 
	public void render(Graphics g) {
		g.setColor(Color.white);
		g.setFont(new Font("arial", 0, 48));
		g.drawString("PAUSED", Game.WIDTH/2-100, 50);
		
		g.drawString("Press Shift to go back", Game.WIDTH/2-230, 330);
	}		
}
