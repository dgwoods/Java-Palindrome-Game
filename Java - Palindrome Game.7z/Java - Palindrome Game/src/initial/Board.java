//CS 143 project - Derrick Woods - 19 May 2019

package initial;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;
import java.util.Stack;

import javax.imageio.ImageIO;

import initial.Game.STATE;


public class Board extends MouseAdapter{

	//Random for mixing up letters available
	private Random random = new Random();
	
	//String corresponding to the name of the file containing the palindromes
	private String palindromeFileName = "Palindromes.txt";
	
	//Ints for tracking the mouse's x/y position on the game board
	private int mouseX = 0;
	private int mouseY = 0;
	
	//Arrays that correspond to the board positions
	public char[] playChars = new char[60], choiceChars = new char[60];
	
	//String corresonding to the currently selected palindrome
	public static String currentPalindrome = "";
	
	//Flags for determining, respectively:  if the tiles have been initialized, if the game should use the normal mode submit function,
	//if the game should use the hard mode submit function, if the currentPalindrome should be shown(player gives up), and
	//if the hint for the currentPalindrome should be shown
	private boolean tilePositionsInitialized = false, checkNormal = false, checkHard = false, revealAnswer = false, showHint = false;
	
	//Ints for tracking the time spent in the current game and transparancy of the position indicator
	private int ticks = 0, transparency = 0;
	public static int time = 0;
	
	//Width and height of the letter tile images (in px)
	private int letterWidth = 90, letterHeight = 85;
	
	//Ints and int arrays that track the currently relevant clicked/hovered elements of the playChars and choiceChars arrays
	private int board = 0, row = 0, column = 0;
	private int[] columns = new int[20], rows = new int[6];
	
	//Origin point and dimenstion info for the play area and choice area
	private int boardOriginX = 62, playOriginY = 62, choiceOriginY = 662, boardWidth = 1819, boardHeight = 257;
	
	
	//Origin and dimension info for the "New Letters" and "Menu" buttons (other buttons are derived from letters button)
	private int btnLettersX = 154, btnLettersY = 450, btnLettersWidth = 200, btnLettersHeight = 64;
	private int btnMenuX = 860, btnMenuY = 950, btnMenuWidth = 150, btnMenuHeight = 64;
	
	//Info of a char grabbed from the arrays
	private char grabbedChar = '\0', hoveredChar = '\0';	//Chars that are currently grabbed and being hovered over respectively, default null
	private int grabbedCharIndex = -1;						//Index of the grabbed char, -1 if nothing grabbed
	private boolean playCharGrabbed = false, choiceCharGrabbed = false;		//Booleans that track if it's a play or choice char grabbed (so it knows where to return it to if necessary)
	
	
	//Tick operations
	public void tick() {	
		ticks++;			//tick triggers every 1/60 of a second
		if (ticks % 60 == 0) {
			time++;				//time spent since start, in seconds
		}
		
		//Initializes the rows and columns arrays at the start
		if (!tilePositionsInitialized) {
			columns[0] = boardOriginX;
			for (int i = 1, k = 1; i < 20; i++, k++) {
				columns[i] = boardOriginX + i*letterWidth + k;
			}
			
			rows[0] = playOriginY;			
			rows[1] = playOriginY + letterHeight + 1;
			rows[2]	= playOriginY + 2*letterHeight + 2;
			rows[3] = choiceOriginY;
			rows[4] = choiceOriginY + letterHeight + 1;
			rows[5] = choiceOriginY + 2*letterHeight + 2;
			
			tilePositionsInitialized = true;
		}
	}
	
											/****   Mouse  ****/
	
	//Returns true if the mouse location (mx/my) is currently hovering over a rectangular area given by the area's origin(x/y) and its dimensions (width/height)
	//Returns true if the mouse location hovered over (mx/my) is within a given rectangular area with passed in x/y origin and the area's width/height
	public boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
		if (mx > x && mx < x+width) {
			if (my > y && my < y+height) {
				return true;
			}
			else
				return false;
		}
		else 
			return false;	
	}
	
	//These track the mouse's x and y positions while it's moving and while it's dragging (moving while a button is held)
	//Locations of the mouse when it moves (regular mouse movement) and when it's dragging (moving while a button is held)
	public void mouseDragged(MouseEvent e) {
		int mX = e.getX();
		int mY = e.getY();
		mouseX = mX;
		mouseY = mY;
	}
	public void mouseMoved(MouseEvent e) {
		int mX = e.getX();
		int mY = e.getY();	
		mouseX = mX;
		mouseY = mY;
	}
	
	
	//Mouse pressed events
	public void mousePressed(MouseEvent e) {
		int mX = e.getX();
		int mY = e.getY();
		
		//Checks if a char is currently grabbed because clicking with the other mouse button while grabbing a char with the other caused issues
		if (Game.gameState == STATE.Game && !playCharGrabbed && !choiceCharGrabbed) {
			
			board = 0;
			//Play area
			if (mouseOver(mX, mY, boardOriginX, playOriginY, boardWidth, boardHeight)) {
				checkNormal = false;
				checkHard = false;
				showHint = false;
				revealAnswer = false;
				board = 1;
				
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + playOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}
		
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}
				
				grabbedChar = playChars[row*20 + column];
				
				if (grabbedChar != '\0') {
					grabbedCharIndex = row*20 + column;
					playChars[grabbedCharIndex] = '\0';
					playCharGrabbed = true;
				}
			}
			
			//Choice area
			else if (mouseOver(mX, mY, boardOriginX, choiceOriginY, boardWidth, boardHeight)) {
				checkNormal = false;
				checkHard = false;
				showHint = false;
				revealAnswer = false;
				board = 2;	
				
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + choiceOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}
				
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}
				
				grabbedChar = choiceChars[row*20 + column];
				
				if (grabbedChar != '\0') {
					grabbedCharIndex = row*20 + column;
					choiceChars[grabbedCharIndex] = '\0';
					choiceCharGrabbed = true;
				}
			}
			
			//New letters Button
			else if (mouseOver(mX, mY, btnLettersX, btnLettersY, btnLettersWidth, btnLettersHeight)) {
				checkNormal = false;
				checkHard = false;
				showHint = false;
				revealAnswer = false;
				choiceChars = new char[60];
				playChars = new char[60];
				KeyInput.charPosition = 0;
				
				String[] palindromeStringArray = getPalindromes(palindromeFileName);
							
				currentPalindrome = getRandomPalindrome(palindromeStringArray);
						
				char[] currentPalindromeCharArray = currentPalindrome.toCharArray();
				for (int i = 0; i < currentPalindromeCharArray.length; i++) {
					choiceChars[i] = currentPalindromeCharArray[i];
				}
				
				choiceChars = normalizeCharArray(choiceChars);
				
				choiceChars = randomizeCharArray(choiceChars);
			}
			//Submit
			else if (mouseOver(mX, mY, btnLettersX+1480, btnLettersY, btnLettersWidth-50, btnLettersHeight)) {
				checkNormal = false;
				checkHard = false;
				showHint = false;
				revealAnswer = false;
				if (Game.difficulty == 0) {
					checkNormal = true;
				}
				else if (Game.difficulty == 1) {
					checkHard = true;
				}
			}
			//Hint
			else if (mouseOver(mX, mY, btnLettersX+1480, btnLettersY-btnLettersHeight-30, btnLettersWidth-50, btnLettersHeight)) {
				if (Game.difficulty == 1) {
					checkNormal = false;
					checkHard = false;
					revealAnswer = false;
					if (currentPalindrome != "") {
						showHint = true;
					}
				}
			}
			//Reveal
			else if (mouseOver(mX, mY, btnLettersX+1480, btnLettersY+btnLettersHeight+30, btnLettersWidth-50, btnLettersHeight)) {
				if (Game.difficulty == 1) {
					checkNormal = false;
					checkHard = false;
					showHint = false;
					if (currentPalindrome != "") {
						revealAnswer = true;
					}
				}
			}
			//Menu
			else if (mouseOver(mX, mY, btnMenuX, btnMenuY, btnMenuWidth, btnMenuHeight)) {
				Game.gameState = STATE.Menu;
			}
		}		
		
		//Prints the board locations clicked for easier troubleshooting
		if (board != 0) {
			String location = "Board: " + board + " - Row: " + row + " - Column: " + column;
			System.out.println(location);
		}
	}
	
	//Mouse released events, only does anything if a char is currently grabbed.
	//Places the grabbed char at the hovered mouse location if it's a valid playChars/choiceChars element (can't already have a char there)
	//Mouse release events, only does anything if a char tile is currently grabbed. Either places the grabbed tile at the postition being
	//hovered over, or returns it from the spot it came if not a valid location(spot occupied or not over a play/choice location)
	public void mouseReleased (MouseEvent e){
		int mX = e.getX();
		int mY = e.getY();
			
		if (choiceCharGrabbed) {
			choiceCharGrabbed = false;
			
			//Play area
			if (mouseOver(mX, mY, boardOriginX, playOriginY, boardWidth, boardHeight)) {
				
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + playOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}		
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}
		
				hoveredChar = playChars[row*20 + column];
				
				if (hoveredChar != '\0') {				
					choiceChars[grabbedCharIndex] = grabbedChar;
					grabbedChar = '\n';
					grabbedCharIndex = -1;
				}
				else {
					playChars[row*20 + column] = grabbedChar;
				}
			}
			
			//Choice area
			else if (mouseOver(mX, mY, boardOriginX, choiceOriginY, boardWidth, boardHeight)) {
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + choiceOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}		
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}

				
				hoveredChar = choiceChars[row*20 + column];
				
				if (hoveredChar != '\0') {				
					choiceChars[grabbedCharIndex] = grabbedChar;
					grabbedChar = '\n';
					grabbedCharIndex = -1;
				}
				else {
					choiceChars[row*20 + column] = grabbedChar;
				}
			}
			//Anywhere else
			else {
				choiceChars[grabbedCharIndex] = grabbedChar;
				grabbedChar = '\n';
				grabbedCharIndex = -1;
			}
		}
		
		else if (playCharGrabbed) {
			playCharGrabbed = false;
			
			//Play area
			if (mouseOver(mX, mY, boardOriginX, playOriginY, boardWidth, boardHeight)) {
				
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + playOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}		
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}
		
				hoveredChar = playChars[row*20 + column];
				
				if (hoveredChar != '\0') {				
					playChars[grabbedCharIndex] = grabbedChar;
					grabbedChar = '\n';
					grabbedCharIndex = -1;
				}
				else {
					playChars[row*20 + column] = grabbedChar;
				}
			}
			
			//Choice area
			else if (mouseOver(mX, mY, boardOriginX, choiceOriginY, boardWidth, boardHeight)) {
				for (int i = 1, j = 2, k = 0;      i < 4;      i++, j--, k++) {
					if (mY >= boardHeight + choiceOriginY - letterHeight*i - k) {
						row = j;
						break;
					}
				}		
				for (int i = 1, j = 19, k = 0;     i < 21;     i++, j--, k++) {
					if (mX >= boardWidth + boardOriginX - letterWidth*i - k) {
						column = j;
						break;
					}
				}

				
				hoveredChar = choiceChars[row*20 + column];
				
				if (hoveredChar != '\0') {				
					playChars[grabbedCharIndex] = grabbedChar;
					grabbedChar = '\n';
					grabbedCharIndex = -1;
				}
				else {
					choiceChars[row*20 + column] = grabbedChar;
				}
			}
			
			//Anywhere else
			else {
				playChars[grabbedCharIndex] = grabbedChar;
				grabbedChar = '\n';
				grabbedCharIndex = -1;
			}
		}
	}

	
	
										/**** Palindrome/Arrays ****/
	
	//Returns true if the passed in string is a palindrome
	private Boolean stringIsPalindrome(String testString) {
		
		char[] stringChars = testString.toCharArray();	
		
		Stack<Character> charStack = new Stack<Character>();		
		for (char c : stringChars) {
			if (Character.isLetter(c)) {
				charStack.push(Character.toUpperCase(c));
			}
		}
		
		for (char c: stringChars) {
			if (Character.isLetter(c)) {
				char stackItem = charStack.pop();
				if (Character.toUpperCase(c) != stackItem) {
					return false;
				}
			}
		}
		
		return true;
	}
	
	//Returns a string array from the file with the name of the passed in string
	private String[] getPalindromes(String s) {
		
		BufferedReader reader = null;
		LinkedList<String> strings = new LinkedList<String>();

		try {
		    File file = new File(s);
		    reader = new BufferedReader(new FileReader(file));
		    String line;
		    
		    while ((line = reader.readLine()) != null) {
		        strings.add(line);	        
		    }

		} catch (IOException ex) {
		    ex.printStackTrace();
		} finally {
		    try {
		        reader.close();
		    } catch (IOException ex) {
		        ex.printStackTrace();
		    }
		}
		
		
		String[] palindromeStringArray = new String[strings.size()]; 
		palindromeStringArray = strings.toArray(palindromeStringArray);
		return palindromeStringArray;		
	}
	
	
	//Returns a random String from the passed in String array and assigns it to currentPalindrome (recurses if the string to be returned is the same as currentPalindrome)
	//Returns a random string from the provided string array and assigns it to currentPalindrome 
	//(recurses if the string it pulled is the same as what's already in currentPalindrome)
	private String getRandomPalindrome(String[] stringArray) {
		int randomArrayIndex = random.nextInt(stringArray.length);
		String s = stringArray[randomArrayIndex];
		if (s == currentPalindrome) {
			getRandomPalindrome(stringArray);
		}
		currentPalindrome = s;
		return s;
	}
	
	//Returns a char array of the same length as the the passed in char array but with all non-letters removed and all letters 
	//converted to uppercase (returned array elements are located at start of array)
	//Takes a char array and returns one with the same length but with only the letters in it (converted to uppercase)
	public char[] normalizeCharArray (char[] charArray) {
		
		int normalizedArrayIndex = 0;
			
		char[] normalizedCharArray = new char[charArray.length];
		for (char c : charArray) {
			if (Character.isLetter(c)) {
				normalizedCharArray[normalizedArrayIndex] = Character.toUpperCase(c);
				normalizedArrayIndex++;
			}
		}
		
		return normalizedCharArray;
	}
	
	//Returns a char array of the same length as the passed in char array with the elements randomized (randomized elements are inserted at start of returned array)
	//Returns char array passed in with the elements randomized (all elements placed at start of array if there are nulls)
	public char[] randomizeCharArray (char[] charArray) {
		
		char[] randomizedArray = new char[charArray.length];
		
		LinkedList<Character> tempList = new LinkedList<Character>();
		for (int i = 0; i < charArray.length; i ++) {
			if (charArray[i] != '\0') {
				tempList.add(charArray[i]);
			}
		}
		
		int numberOfChars = tempList.size();
		for (int i = 0; i < numberOfChars; i ++) {
			int r = random.nextInt(tempList.size());
			randomizedArray[i] = tempList.get(r);
			tempList.remove(r);
		}
		
		return randomizedArray;
	}
	

											/**** Renders ****/
	
	//Inform player if played string was a palindrome or not and show the string's chars forwards and backwards
	private void renderNormalCheck(Graphics g) {
		
		String submission = "";
		Stack<Character> reversed = new Stack<Character>();
		for(char c : playChars) {
			if (c != '\0') {
				submission += c;
				reversed.push(c);
			}
		}
		
		if (submission != "") {
			int charSpacer = 0;
			Font fnt = new Font("arial", 1, 20);
			Font fnt2 = new Font("arial", 1, 50);
			g.setFont(fnt2);
			if (stringIsPalindrome(submission)) {
				g.drawString("- That's a palindrome! -", btnLettersX+btnLettersWidth+340, btnLettersY-70);
				g.setFont(fnt);
				g.drawString("Forward", btnLettersX+btnLettersWidth+20, btnLettersY-10);
				g.drawString("Backwards", btnLettersX+btnLettersWidth+20, btnLettersY+btnLettersHeight+35);
				for (char c : playChars) {
					if (c != '\0') {
						g.drawString(Character.toString(c), btnLettersX+btnLettersWidth+50+charSpacer, btnLettersY+15);
						g.drawString("|", btnLettersX+btnLettersWidth+52+charSpacer, btnLettersY+45);
						g.drawString(Character.toString(reversed.pop()), btnLettersX+btnLettersWidth+50+charSpacer, btnLettersY+75);
						charSpacer+=40;
					}
				}
			}
			else {
				g.drawString("Incorrect", btnLettersX+btnLettersWidth+500, btnLettersY-70);
				g.setFont(fnt);
				g.drawString("Forward", btnLettersX+btnLettersWidth+20, btnLettersY-10);
				g.drawString("Backwards", btnLettersX+btnLettersWidth+20, btnLettersY+btnLettersHeight+35);
				for (char c : playChars) {
					if (c != '\0') {
						g.drawString(Character.toString(c), btnLettersX+btnLettersWidth+50+charSpacer, btnLettersY+15);
						g.drawString("|", btnLettersX+btnLettersWidth+52+charSpacer, btnLettersY+45);
						g.drawString(Character.toString(reversed.pop()), btnLettersX+btnLettersWidth+50+charSpacer, btnLettersY+75);
						charSpacer+=40;
					}
				}
			}
		}
	}
	
	//Inform player if played string matches the palindrome that the letters came from
	private void renderHardCheck (Graphics g) {
		int letterCount = 0;
		Font fnt = new Font("arial", 1, 20);
		Font fnt2 = new Font("arial", 1, 50);
		g.setFont(fnt2);
		
		char[] charArray = currentPalindrome.toCharArray();
		charArray = normalizeCharArray(charArray);
		for (char c : charArray) {
			if (Character.isLetter(c)) {
				letterCount++;
			}
		}
		char[] tempArray = new char[letterCount];
		for (int i = 0, j = 0; i < charArray.length; i++) {
			if (Character.isLetter(charArray[i])) {
				tempArray[j] = charArray[i];
				j++;
			}
		}
		
		g.setFont(fnt);
		for(int i = 0, j = 0; i < 60; i ++) {
			if (playChars[i] == '\0') {
				if (choiceChars[i] != '\0') {
					g.drawString("Incorrect", btnLettersX+btnLettersWidth+500, btnLettersY-70);
					break;
				}
			}
			if (playChars[i] != '\0' && playChars[i] != tempArray[j]) {
				g.drawString("Incorrect", btnLettersX+btnLettersWidth+500, btnLettersY-70);
				break;
			}
			if (playChars[i] != '\0' && playChars[i] == tempArray[j]){
				j++;
				System.out.println(j);
				if (j == tempArray.length) {
					g.drawString("- That's Correct! -", btnLettersX+btnLettersWidth+450, btnLettersY-70);
					//g.setFont(fnt);
					g.drawString("Palindrome: " + currentPalindrome, btnLettersX+btnLettersWidth+52, btnLettersY+45);
					break;
				}
			}
		}	
	}
	
	//Renders the the letter tile images at the locations corresponding to the playChars/choiceChars elements
	//Renders the tile images over the play/choice boards, renders nothing if the array corresponding array element is null
	private void renderTiles (Graphics g) {
		char charToRender;
		for (int i = 0; i < 60; i++) {
			charToRender = choiceChars[i];
			if (charToRender != '\0') {
				try {
					Image letterTile = ImageIO.read(new File("Image/"+charToRender+".jpg"));			
					if (i < 20) {
						g.drawImage(letterTile, columns[i], rows[3], null);
					}
					else if (i < 40) {
						g.drawImage(letterTile, columns[i-20], rows[4], null);
					}
					else {
						g.drawImage(letterTile, columns[i-40], rows[5], null);
					}
				}
				catch (Exception ex) {
					
				}
			}
			
			charToRender = playChars[i];
			if (charToRender != '\n') {
				try {
					Image letterTile = ImageIO.read(new File("Image/"+charToRender+".jpg"));			
					if (i < 20) {
						g.drawImage(letterTile, columns[i], rows[0], null);
					}
					else if (i < 40) {
						g.drawImage(letterTile, columns[i-20], rows[1], null);
					}
					else {
						g.drawImage(letterTile, columns[i-40], rows[2], null);
					}
				}
				catch (Exception ex) {
					
				}
			}
		}	
	}
	
	//Renders transparent blue rectangle that shows where any keyboard entries will go
	private void renderPositionIndicator(Graphics g) {
		if (ticks % 120 < 61) {
			transparency++;
		}
		else {
			transparency--;
		}
		if (transparency > 60) {
			transparency = 60;
		}
		else if (transparency < 0) {
			transparency = 0;
		}
		g.setColor(new Color(0,206,209, transparency));
							
		if (KeyInput.charPosition < 20) {
			g.fillRect(columns[KeyInput.charPosition], rows[0], letterWidth, letterHeight);
		}
		else if (KeyInput.charPosition < 40) {
			g.fillRect(columns[KeyInput.charPosition - 20], rows[1], letterWidth, letterHeight);
		}
		else {
			g.fillRect(columns[KeyInput.charPosition - 40], rows[2], letterWidth, letterHeight);
		}	
	}
	
	//Renders the individual elemtents of the board
	public void render(Graphics g) {
		//Tracks the time spent
		g.setColor(Color.white);	
		g.drawString("Time: " + time + "s", 880, 32);
		
		
		
					/*The upper play area*/
		
		//Background tan color of the letter locations
		g.setColor(new Color(200,145,90));
		g.fillRect(62, 62, letterWidth*20 + 19, letterHeight*3 + 2);		
		
		//Black borders of the letter areas, these two are the horizontal lines
		g.setColor(Color.black);
		g.drawLine(61, 62+letterHeight, 82+ letterWidth*20, 62+letterHeight);
		g.drawLine(61, 63+ 2*letterHeight, 82+ letterWidth*20, 63+ 2*letterHeight);	
		
		//The nineteen vertical lines
		for (int i = boardOriginX, j = 1; i < boardOriginX+19; i++, j++) {
			g.drawLine(i + j*letterWidth, playOriginY, i + j*letterWidth, playOriginY + 3*letterHeight + 1);
		}
		
		
		//Rectangle that serves as the lines on the outside
		g.drawRect(61, 61, letterWidth*20 + 21, letterHeight*3 + 4);
		
		//Border around the rest of the area that's a dark brown color
		g.setColor(new Color(100,67,33));
		g.drawRect(60, 60, letterWidth*20 + 23, letterHeight*3 + 6);
		
		
		
					/*The lower play area*/
		
		//Background tan color of the letter locations
		g.setColor(new Color(200,145,90));
		g.fillRect(62, 662, letterWidth*20 + 19, letterHeight*3 + 2);		
		
		//Black borders of the letter areas, these two are the horizontal lines
		g.setColor(Color.black);
		g.drawLine(61, 662+letterHeight, 82+ letterWidth*20, 662+letterHeight);
		g.drawLine(61, 663+ 2*letterHeight, 82+ letterWidth*20, 663+ 2*letterHeight);
		
		//The nineteen vertical lines		
		for (int i = boardOriginX, j = 1; i < boardOriginX+19; i++, j++) {
			g.drawLine(i + j*letterWidth, choiceOriginY, i + j*letterWidth, choiceOriginY + 3*letterHeight + 1);
		}
		
		//Rectangle that serves as the lines on the outside
		g.drawRect(61, 661, letterWidth*20 + 21, letterHeight*3 + 4);
		
		//Border around the rest of the area that's a dark brown color
		g.setColor(new Color(100,67,33));
		g.drawRect(60, 660, letterWidth*20 + 23, letterHeight*3 + 6);			
		
		
		//Render tile images
		renderTiles(g);
		
		
		
		//Differing font sizes so the menu options fit
		Font fnt = new Font("arial", 1, 15);
		Font fnt2 = new Font("arial", 1, 30);
			
		//New letters button
		g.setColor(Color.white);
		g.setFont(fnt2);
		g.drawRect(btnLettersX, btnLettersY, btnLettersWidth, btnLettersHeight);
		g.drawString("New Letters", btnLettersX+13, btnLettersY+40);
		
		//Submit button
		g.drawRect(btnLettersX+1480, btnLettersY, btnLettersWidth-50, btnLettersHeight);
		g.drawString("Submit", btnLettersX+1502, btnLettersY+40);
		
		//Reveal and hint buttons shown if on hard mode
		if (Game.difficulty == 1) {
			g.drawRect(btnLettersX+1480, btnLettersY-btnLettersHeight-30, btnLettersWidth-50, btnLettersHeight);
			g.drawString("Hint", btnLettersX+1522, btnLettersY-btnLettersHeight+10);
			
			g.drawRect(btnLettersX+1480, btnLettersY+btnLettersHeight+30, btnLettersWidth-50, btnLettersHeight);
			g.drawString("Reveal", btnLettersX+1502, btnLettersY+btnLettersHeight+70);
		}
		
		
		//Show the current palindrome's hint (number of words in the palindrome) if in hard mode, hint button clicked, and the current palindrome isn't null
		if (showHint) {
			int numberOfSpaces = 0;
			for (char c : currentPalindrome.toCharArray()) {
				if (Character.isSpaceChar(c)) {
					numberOfSpaces++;
				}
			}
			if (currentPalindrome != "") {
				numberOfSpaces++;		
				g.drawString("Hint: The palindrome is composed of " + numberOfSpaces + " words.", btnLettersX+btnLettersWidth+52, btnLettersY+45);
			}
		}
		//Show the current palindrome if in hard mode, reveal button clicked, and the current palindrome isn't null
		if (revealAnswer) {
			g.drawString("Palindrome: " + currentPalindrome, btnLettersX+btnLettersWidth+52, btnLettersY+45);
		}
		
		// MENU
		g.drawRect(btnMenuX, btnMenuY, btnMenuWidth, btnMenuHeight);
		g.drawString("Menu", btnMenuX+35, btnMenuY+44);
		
		
		//Render the tile that was clicked(grabbed) at the mouse position
		if (playCharGrabbed || choiceCharGrabbed) {
			try {
			Image letterTile = ImageIO.read(new File("Image/"+grabbedChar+".jpg"));
			g.drawImage(letterTile, mouseX - letterWidth/2, mouseY - letterHeight/2, null);
			}
			catch (Exception ex) {
			}
		}
		
		//Submission result for normal
		if (checkNormal) {
			renderNormalCheck(g);
		}
		//Submission result for hard
		else if (checkHard) {
			renderHardCheck(g);
		}
		
		//Render blue array position indicator
		renderPositionIndicator(g);
	}
}
