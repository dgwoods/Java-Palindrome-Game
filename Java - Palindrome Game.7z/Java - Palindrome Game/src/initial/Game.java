//CS 143 project - Derrick Woods - 19 May 2019
package initial;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferStrategy;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Game  extends Canvas implements Runnable{
	
	private static final long serialVersionUID = 1482420271242907776L;

	//Dimensions of the game window
	//public static final int WIDTH = 640, HEIGHT = WIDTH / 4 * 3;
	public static final int WIDTH = 1920, HEIGHT = WIDTH / 16 * 9;
	
	//One thread does the processing
	private Thread thread;
	private boolean running = false;
	
	//difficulty 0 = normal and 1 = hard
	public static int difficulty = 0;
	
	private Random r;
	private Board board;
	private Menu menu;
	private PauseScreen pauseScreen;
	
	//Enumeration that tracks what state the game is currently in so it knows what should be shown.
	public enum STATE {
		Menu,
		Game, 
		Help,
		Select,
		Paused;
	}
	
	//Game starts off in the menu
	public static STATE gameState = STATE.Menu;
	
	public Game() {
		board = new Board();
		pauseScreen = new PauseScreen();
		menu = new Menu(this, board);
		this.addKeyListener(new KeyInput(this, board));
		this.addMouseListener(menu);
		this.addMouseListener(pauseScreen);
			
		new Window(WIDTH, HEIGHT, "Palindrome Game", this);
			
		r = new Random();
	
		this.requestFocusInWindow();
	}
	
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void run() {
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;  //This is the actual loop of the game that updates every 1/60 of a second
		double delta = 0;
		long timer = System.currentTimeMillis();
		
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			
			while(delta >= 1) {
				tick();
				delta--;
			}
			if(running) {
				render();
				try {
					TimeUnit.MILLISECONDS.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if (System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
			}
		}
		stop();
	}
	
	private void tick() {				
		
		if (gameState == STATE.Game) {
			board.tick();		
		}
		else if (gameState == STATE.Paused) {		//No need to run any tick operations if paused
			
		}
		else {
			menu.tick();
		}
	}
	
	private void render() {
		
		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		g.setColor(new Color(160,105,50));
		g.fillRect(0, 0, WIDTH, HEIGHT);			
		
		if (gameState == STATE.Game) {     //Render the necessary components based on the screen currently being displayed
			board.render(g);
		}
		else if (gameState == STATE.Paused){
			pauseScreen.render(g);
		}
		else{
			menu.render(g);
		}
		
		g.dispose();
		bs.show();
	}
	
	public static void main(String args[]) {
		new Game();
	}
}
